package com.neo.transformer;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class RequestVO implements Processor{
	
	public void process(Exchange exchange) throws Exception {
		System.out.println( "message exchange" + exchange.getIn().getBody());	
	}

}
