package com.neo.transformer;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.neo.pojo.Employee;
import com.neo.pojo.Person;

public class ResponseBO implements Processor{
	
	public void process(Exchange exchange) throws Exception {
		System.out.println( "message exchange" + exchange.getIn().getBody());	
		Person person = new Person();
		List<Employee> employees = (List<Employee>) exchange.getIn().getBody();
		person.setFirst_name(employees.get(0).getFirstName());
		person.setLast_name(employees.get(0).getLastName());
		person.setSalary(String.valueOf(employees.get(0).getSalary()));
		exchange.getIn().setBody(person, Person.class);

	}

}
