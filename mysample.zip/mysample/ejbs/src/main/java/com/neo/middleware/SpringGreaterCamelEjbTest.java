package com.neo.middleware;

import org.apache.camel.test.spring.CamelSpringTestSupport;
import org.junit.Test;
import org.springframework.context.support.AbstractXmlApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringGreaterCamelEjbTest extends CamelSpringTestSupport {

    @Override
    protected AbstractXmlApplicationContext createApplicationContext() {
        return new ClassPathXmlApplicationContext("camelContext.xml");
    }

    @Test
    public void testGreaterViaCamelEjb() throws Exception {
        getMockEndpoint("mock:result").expectedBodiesReceived("Hello World");

        template.sendBody("direct:start", "World");

        assertMockEndpointsSatisfied();
    }

    @Test
    public void testLocateOtherBeans() throws Exception {
        GreaterLocal mySpringBean = context().getRegistry().lookupByNameAndType("mySpringBean", GreaterLocal.class);
        assertNotNull("We should get the instance of spring bean", mySpringBean);
    }

}