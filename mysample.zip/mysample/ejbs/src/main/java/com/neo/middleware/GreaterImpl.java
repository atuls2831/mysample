package com.neo.middleware;




import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import com.neo.dao.EmployeeDao;
import com.neo.pojo.Employee;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class GreaterImpl implements GreaterLocal {
	
    public List<Employee> hello(String name) {
    	System.out.println("Hello " + name);
    	System.out.println("start") ;
    	try {
			wait1();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println("stop") ;
		EmployeeDao enp = new EmployeeDao();  	
    	List<Employee> employees = enp.listEmployees();
        return employees;
    }

    public String bye(String name) {
        return "Bye " + name;
    }
    public static void wait1() throws InterruptedException {
    	//Thread.sleep(50000);
    }
}