package com.neo.middleware;




import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import com.neo.dao.EmployeeDao;
import com.neo.pojo.Employee;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class GreaterImpl implements GreaterLocal {
	
    public List<Employee> hello(String name) {
    	System.out.println("Hello " + name);
    	System.out.println("start") ;
    	System.out.println("stop") ;
		EmployeeDao enp = new EmployeeDao();  	
    	List<Employee> employees = enp.listEmployees();
        return employees;
    }

    public String bye(String name) {
        return "Bye " + name;
    }
   
}