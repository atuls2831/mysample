package com.neo.middleware;




import javax.ejb.Stateless;

@Stateless
public class GreaterImpl implements GreaterLocal {

    public String hello(String name) {
    	System.out.println("Hello " + name);
        return "Hello " + name;
    }

    public String bye(String name) {
        return "Bye " + name;
    }

}