package com.neo.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.neo.pojo.Employee;

public class EmployeeDao {
	
	   private static SessionFactory factory; 
	


	   
	   /* Method to  READ all the employees */
	   public List<Employee> listEmployees( ){
		   List<Employee> employees = null;
		   try {
			  
		         factory = new Configuration().configure().buildSessionFactory();
		      } catch (Throwable ex) { 
		         System.err.println("Failed to create sessionFactory object." + ex);
		         throw new ExceptionInInitializerError(ex); 
		      }
		   
	      Session session = factory.openSession();
	      Transaction tx = null;
	      
	      try {
	    	  
	         tx = session.beginTransaction();
	      
	         employees = session.createQuery("select e FROM Employee e").list(); 
	         for (Iterator<Employee> iterator = employees.iterator(); iterator.hasNext();){
	            Employee employee = iterator.next(); 
	            System.out.print("First Name: " + employee.getFirstName()); 
	            System.out.print("  Last Name: " + employee.getLastName()); 
	            System.out.println("  Salary: " + employee.getSalary()); 
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	      return employees;
	   }
}
