package com.neo.middleware;

import java.util.List;

import com.neo.pojo.Employee;

public interface GreaterLocal {

	List<Employee> hello(String name);

    String bye(String name);

}