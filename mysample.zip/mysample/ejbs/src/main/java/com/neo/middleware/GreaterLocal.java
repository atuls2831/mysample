package com.neo.middleware;



public interface GreaterLocal {

    String hello(String name);

    String bye(String name);

}