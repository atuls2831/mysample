package com.neo.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface Greet {
	@WebMethod
	  public String greetClient(String userName);

}
