package com.neo;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;

public  class CallingClass {
	
	
	static {
		int i =1;
		System.out.println("called" + i );
	}
	
	public  static String callFurther (CamelContext camelContext , String user) {
		String returnValue = null;
		try {

			ProducerTemplate producer = camelContext.createProducerTemplate();
			returnValue = (String) producer.requestBody("direct:start",user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return returnValue;
		
	}

}
