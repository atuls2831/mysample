package com.neo.webservice;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.neo.CallingClass;

//@WebServlet(name = "GreetingWebService", urlPatterns = {"/send/*"}, loadOnStartup = 1)
public class Greeting extends HttpServlet 
{
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//static ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext("classpath:META-INF/camel-context.xml");
	//CamelContext camelContext = (CamelContext) appContext.getBean("mysampleCamel");
	
	@Resource(name = "java:jboss/camel/context/mysampleCamel")
	private CamelContext camelContext;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		// set response headers
				response.setContentType("text/html");
				response.setCharacterEncoding("UTF-8");
				
				// create HTML form
				PrintWriter writer = response.getWriter();
				writer.append("<!DOCTYPE html>\r\n")
					  .append("<html>\r\n")
					  .append("		<head>\r\n")
					  .append("			<title>Form input</title>\r\n")
					  .append("		</head>\r\n")
					  .append("		<body>\r\n")
					  .append("			<form action=\"welcome\" method=\"POST\">\r\n")
					  .append("				Enter your name: \r\n")
					  .append("				<input type=\"text\" name=\"user\" />\r\n")
					  .append("				<input type=\"submit\" value=\"Submit\" />\r\n")
					  .append("			</form>\r\n")
					  .append("		</body>\r\n")
					  .append("</html>\r\n");
			}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String user = request.getParameter("user");
		
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		//System.out.println(new CallingClass());
		
		String returnValue = null;

		try {
			System.out.println("camelContext hascode " + camelContext.hashCode());
			ProducerTemplate producer = camelContext.createProducerTemplate();
			returnValue = (String) producer.requestBody("direct:start",user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
		// create HTML response
		PrintWriter writer = response.getWriter();
		writer.append("<!DOCTYPE html>\r\n")
			  .append("<html>\r\n")
			  .append("		<head>\r\n")
			  .append("			<title>Welcome message</title>\r\n")
			  .append("		</head>\r\n")
			  .append("		<body>\r\n");
		if (user != null && !user.trim().isEmpty()) {
		
			writer.append("	You successfully completed this javatutorial.net example.\r\n");
			writer.append(returnValue);
		} else {
			writer.append("	You did not entered a name!\r\n");
		}
		writer.append("		</body>\r\n")
			  .append("</html>\r\n");
	}	
	//return returnValue;
			
}
	
	
